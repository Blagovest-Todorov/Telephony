﻿namespace Telephony.Interfaces
{
    public interface ICallable
    {
        public string Call(string phoneNr);
    }
}
