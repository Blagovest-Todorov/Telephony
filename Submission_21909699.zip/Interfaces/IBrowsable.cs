﻿namespace Telephony.Interfaces
{
    public interface IBrowsable
    {
        public string Browse(string urlSite);
    }
}
